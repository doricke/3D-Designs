class InitDatum < ActiveRecord::Base
end
