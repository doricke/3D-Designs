module LicensesHelper
end
